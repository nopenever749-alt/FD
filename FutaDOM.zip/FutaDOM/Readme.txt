Mod made by Dirty Old Man, this one contains all my Futanari content,
Will have a bunch of other fetishes too but it's mainly heavy futadom stuff.
If you want 'normal' femdom content check out my mod femDOM.
Currently this mod only has 2 actual fights, but it has a introduction quest, changes things in town and has new events.
as well as a pretty neat story segment.

In general this whole thing is to see how well I can tell a story this modding engine.
I've also kinda found working on it as an enjoyable way to kill time.

To start the mod there's a quest to go on a walk in the woods, you'll quickly figure out that regular attacks are pretty useless
against the newer enemies, try asking Amber for help! Oh but don't let them cum inside of you!

So right WARNING
I'd consider a keeping a save without this modpack so when I update it with triggers
you can play through it again and hit those triggers properly!
I'd say consider a new game but a lot of the monsters in this pack will be pretty tough.
If you have problems with this mod please let me know on discord!

Everyone in this mod is 18+ I swear officer